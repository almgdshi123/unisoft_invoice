<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDepAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dep_accounts', function (Blueprint $table) {
            $table->id();
            $table->string('id_Invoice', 50);
            $table->unsignedBigInteger('id_box');
            $table->decimal('Value_VAT',15)->nullable();
            $table->decimal('Total',15)->nullable();
            $table->string('Created_by',15);
            $table->boolean('Value_Status');
            $table->foreign('id_box')->references('id')->on('box_accounts')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dep_accounts');
    }
}
