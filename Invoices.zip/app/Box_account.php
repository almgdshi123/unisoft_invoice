<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Box_account extends Model
{
    protected $fillable = [
         'customer_id','Total'
        ];
}
